#批量修改文件名前缀
foreach my $file (glob "*"){ #查找当前目录下所有以“a”为前缀的文件
my $newFile = $file;
$newFile =~ s/$ARGV[0]/$ARGV[1]/; #将“a”前缀改为“b”
if(-e $newFile){ #如果修改后会导致文件重名，则输出警告，不作处理
warn "Can't rename $file to $newFile. The $newFile exists!\n";
}else{
rename $file, $newFile #重命名文件
or
warn "Rename $file to $newFile failed: $!\n"; #如果重命名失败，则输出警告
}
}
